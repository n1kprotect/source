from .api import (Client,)

__author__ = 'Cazqev'
__version__ = '1.0.0'
__email__ = 'nikprotect@gmail.com'