import requests
import json
import urllib.parse
import datetime


class MyFile:
    def __init__(self, obj):
        js0 = obj['json[0]']
        js1 = obj['json[1]']
        path = obj['path_']
        resources = js1['resources'][path]
        self.name = resources['name']
        self.short_url = resources['meta']['short_url']
        self.size = resources['meta']['size']
        self.last_modified = datetime.datetime.utcfromtimestamp(resources['modified']).strftime('%Y-%m-%d %H:%M:%S')
        self.download_url = js0['data']['url']


class Client:
    def __init__(self,
                 settings: dict = {},
                 proxy: dict = None):

        self.yandexuid = settings['yandexuid']
        self.yuidss = settings['yuidss']
        self.ymex = settings['ymex']
        self._ym_uid = settings['_ym_uid']
        self._ym_d = settings['_ym_d']
        self._yasc = settings['_yasc']
        self.skid = settings['skid']
        self.Session_id = settings['Session_id']
        self.sessionid2 = settings['sessionid2']
        self.yandex_login = settings['yandex_login']
        self.i = settings['i']

        self.cli = requests.Session()
        if proxy:
            self.cli.proxies = proxy
        self.api_url = 'https://disk.yandex.ru/public/api/download-url'

    def __X_load___(self, disk_url: str):
        cookies = {
            'yandexuid': self.yandexuid,
            'yuidss': self.yuidss,
            'ymex': self.ymex,
            '_ym_uid': self._ym_uid,
            '_ym_d': self._ym_d,
            'gdpr': '0',
            'skid': self.skid,
            'is_gdpr': '1',
            'is_gdpr_b': 'COrYehDHYRgB',
            'bltsr': '1',
            '_yasc': self._yasc,
            'prodqad': '1',
            'Session_id': self.Session_id,
            'sessionid2': self.sessionid2,
            'yp': '1635018848.mcl.#1635018848.mct.null#1635018848.mcv.0#1634500448.nps.2993741297%3Aclose#1635018848.szm.1_25%3A1536x864%3A1536x714#1961399976.udn.cDplcmhlcnRobmp0aWo%3D#1952287638.multib.1',
            'ys': 'udn.cDplcmhlcnRobmp0aWo%3D',
            'L': 'V1JaX3tdUXUGVmZEdwJuQl55WWwAeUx0N0I+VgMGWCIPAjFb.1646039976.14902.321779.e4cf6be88b3fc014d88e39ff540358bb',
            'yandex_login': self.yandex_login,
            'i': self.i,
        }

        headers = {
            'Connection': 'keep-alive',
            'Cache-Control': 'max-age=0',
            'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-User': '?1',
            'Sec-Fetch-Dest': 'document',
            'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
            'If-None-Match': 'W/"7604-kHzzdJo20S7YiGWKMsJf6sL8WpY"',
        }

        response = requests.get(disk_url, headers=headers, cookies=cookies)
        api_data = '{' + response.text.split('<script type="application/json" id="store-prefetch">{')[1].split(
            ',"photoGrid":{"byResource":{},"structureVersion":0}}</script>')[
            0] + ',"photoGrid":{"byResource":{},"structureVersion":0}}'
        api_data_json = json.loads(api_data)
        fl = api_data_json['resources']
        path = str(fl).split("'")[1].split("'")[0]
        values = fl[path]
        hash = values['hash']
        uid = values['uid']
        sk = api_data_json['environment']['authSk']

        headers = {
            'Connection': 'keep-alive',
            'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="98", "Google Chrome";v="98"',
            'sec-ch-ua-mobile': '?0',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36',
            'sec-ch-ua-platform': '"Windows"',
            'Content-Type': 'text/plain',
            'Accept': '*/*',
            'Origin': 'https://disk.yandex.ru',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://disk.yandex.ru/d/kBQzj1XSJ56yPg',
            'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        }
        data = urllib.parse.quote(
            json.dumps({"hash": hash, "sk": "ubd198fc3e78361d02cdbe857cf2b1e9c", "uid": "1291551515"}))
        response = requests.post('https://disk.yandex.ru/public/api/download-url', headers=headers, cookies=cookies,
                                 data=data)
        return {'json[0]': response.json(), 'json[1]': api_data_json, 'path_': path}

    def get_file(self, disk_url: str):
        return MyFile(self.__X_load___(disk_url))
